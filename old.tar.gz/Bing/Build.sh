### AIDE PRO
# *TELEGRAM (@SANT_HAX)

[[ "$(id -u)" != "2000" && "$(id -u)" != "0" ]] && echo "\e[31mROOT\e[0m" && exit

Pns=("com.idragoncheats.studio" "com.idragoncheats.studiopro" "com.goxome.aidestudio" "com.aide.ui.crustacean")  #AIDE PACKAGE TOD
Fd=()  # 找到的包名

for Pn in "${Pns[@]}"
do
    [ -e "/data/user/0/${Pn}/no_backup/ndksupport-1710240003/android-ndk-aide/ndk-build" ] && Fd+=("${Pn}")
done
[ ${#Fd[@]} -eq 0 ] && echo "\e[31mndk-build\e[0m" && exit 1
if [ ${#Fd[@]} != 1 ] ; then
    echo "\e[31mSelect Your 个ndk-build，Already have this\e[0m"
    for i in "${!Fd[@]}"; do
        echo "\e[33m[$((i+1))]\e[90m ->\e[37m ${Fd[i]}\e[0m"
    done
    read Input
    if [[ $Input -ge 1 && $Input -le ${#Fd[@]} ]]; then
        UsePN="${Fd[$((Input-1))]}"
    else
        echo "\e[31mWRONG KONTOL1~${#Fd[@]}\e[0m"
        exit 1
    fi
else
    UsePN="${Fd[0]}"
fi

echo "\e[35m开始编译
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
Running || Tg > Sant_Hax
\e[0m"
/data/user/0/${UsePN}/no_backup/ndksupport-1710240003/android-ndk-aide/ndk-build 2>&1

[ $? -eq 0 ] && echo "\e[32mMake Success\e[0m" || { echo "\e[31mMake Failed\e[0m" && exit 1; }

tmp=/data/local/tmp
rm -rf ${tmp}/SANTCHEAT && mv ./libs/**/* ${tmp}/SANTCHEAT && chmod +x ${tmp}/SANTCHEAT
echo "\n\e[33mDONTOL\e[0m\n"
${tmp}/SANTCHEAT
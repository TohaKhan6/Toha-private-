#ifndef NATIVESURFACE_DRAW_H
#define NATIVESURFACE_DRAW_H
#include <stdio.h>
#include <stdlib.h>
#include "ImGui/imgui.h"
#include "ImGui/imgui_internal.h"
#include "native_surface/ANativeWindowCreator.h"
#include "AndroidImgui.h"
#include "touch.h"//触摸
#include "timer.h"
#include "my_imgui.h"     //字体

extern ANativeWindow *window;
extern android::ANativeWindowCreator::DisplayInfo displayInfo;
extern ImGuiWindow *g_window;
extern int native_window_screen_x, native_window_screen_y;
extern std::unique_ptr<AndroidImgui>  graphics;
extern ImFont* zh_font;
extern std::string imeienc;
extern void screen_config();
extern void drawBegin();
extern void init_My_drawdata();
extern void cfgSave(const char *name);
extern void cfgLoad(const char *name);
extern std::string exec(std::string command);
extern void closedriver();
extern void initoxdriver();
extern void initkernel();
extern bool isend,isyz,isyz2;
extern bool swh[50];
extern int val[50];

extern bool menu();

#endif //NATIVESURFACE_DRAW_H
#include <sys/fcntl.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <ctype.h>
#include <fstream>
#include <sstream>
#include <sys/fcntl.h>
#include <sys/ioctl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <map>
#include <vector>
#include <algorithm>
#include <dirent.h>
#include <unistd.h>
#include <chrono>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/kdev_t.h>
#include <sys/sysmacros.h>
#include <iostream>
using namespace std;

typedef unsigned short UTF16;
typedef char UTF8;

class c_driver {
private:
    int fd;
    typedef struct _COPY_MEMORY {
        pid_t pid;
        uintptr_t addr;
        void* buffer;
        size_t size;
        int yz;
    } COPY_MEMORY, *PCOPY_MEMORY;

    typedef struct _MODULE_BASE {
        pid_t pid;
        char* name;
        uintptr_t base;
    } MODULE_BASE, *PMODULE_BASE;

    enum OPERATIONS {
        OP_READ_MEM = 0x801,
        OP_WRITE_MEM = 0x802,
        OP_MODULE_BASE = 0x803,
    };
    
    bool StrAlpha(const char *str) {
        for (int i = 0; i < 6; i++) {
            if (!isalpha(str[i])) {
                return false;
            }
        }
        return true;
    }

    int OpenFd() {
        DIR *dir;
        struct dirent *ptr;
        struct stat info;
        dir = opendir("/proc");
        ssize_t len;
        char path[256];
        char buffer[256];
        char fd_path[256];
        char fd_buffer[256];
        char dev_path[256];
        char data_path[128];
        int ID;
        int PPID;
        
        while ((ptr = readdir(dir)) != NULL) {
            if (ptr->d_type == DT_DIR) {
                sprintf(buffer, "/proc/%d/exe", atoi(ptr->d_name));
                // printf("文件夹: %s\n  路径: %s", ptr->d_name, buffer);
                len = readlink(buffer, path, sizeof(path) - 1);
                if (len != -1) path[len] = '\0';
                char* stres = strrchr(path, '(deleted)');
                if (stres != NULL) {
                    sscanf(path, "/data/%s", &data_path);
                    if (StrAlpha(data_path)) {
                        sscanf(buffer, "/proc/%d/exe", &PPID);
                        //printf("[+] 软链: %s  PID: %d\n", path, PPID);
                        for (int i = 3; i < 5; i++) {
                            sprintf(fd_path, "/proc/%d/fd/%d", PPID, i);
                            len = readlink(fd_path, fd_buffer, sizeof(fd_buffer) - 1);
                            char* stress = strrchr(fd_buffer, '(deleted)');
                            if (stress != NULL) {
                                int fd_file = open(fd_path, O_RDONLY);
                                if (fd_file == -1) {
                                    perror("open");
                                    close(fd_file);
                                    return EXIT_FAILURE;
                                }
                                if (fstat(fd_file, &info) == -1) {
                                    perror("fstat");
                                    close(fd_file);
                                    return 0;
                                }
                                sscanf(fd_buffer, "%s (deleted)", dev_path);
                                printf("%s\n", dev_path);
                                //printf("[*] 主设备号: %lu\n", major(info.st_rdev));
                                //printf("[*] 次设备号: %lu\n", minor(info.st_rdev));
                                if (access(dev_path, F_OK) == 0) {  // 检查文件是否存在
                                    ID = open(dev_path, O_RDWR);
                                    if (ID != -1) {
                                        //printf("[+] 驱动识别成功\n");
                                        if (unlink(dev_path) == 0) {
                                            //printf("[+] 驱动守护中\n");
                                            //printf("[+] 读取驱动用时: %.f ms\n", elapsed_ns);
                                            close(fd_file);
                                            closedir(dir);
                                            return ID;
                                            // return 0;
                                        }
                                    }
                                } else { // 驱动已经隐藏
                                    //printf("[+] 驱动已隐藏创建驱动中\n");
                                    mode_t mode = S_IFCHR | 0666; // 创建一个命名管道，权限为读写
                                    dev_t dev = makedev(major(info.st_rdev), minor(info.st_rdev));
                                    if (mknod(dev_path, mode, dev) != -1) {
                                        //printf("[+] mknod : %d 成功\n", major(info.st_rdev));
                                    }
                                    ID = open(dev_path, O_RDWR);
                                    if (ID != -1) {
                                        //printf("[+] 驱动识别成功\n");
                                        if (unlink(dev_path) != -1) {
                                            //printf("[+] 驱动守护中\n");
                                            close(fd_file);
                                            closedir(dir);
                                            return ID;
                                        }
                                    }
                                }
                                close(fd_file);
                                break;
                            }
                        }
                        break;
                    }
                }
            }
        }
        closedir(dir);
        printf("[+] 未识别到QX驱动程序\n");
        return -1;
    }
    
public:
    pid_t pid;
    c_driver(){
        fd=OpenFd();
        if (fd == -1) {
            printf("\033[31m[X] 驱动连接失败 \033[0m\n");
            exit(0);
        } else {
            printf("\033[32m[✓] 驱动连接成功 \033[0m\n");
        }
    }

    ~c_driver() {
        if (fd > 0)
            close(fd);
    }

    void initialize(pid_t pid) {
        this->pid = pid;
    }

    bool read(uintptr_t addr, void *buffer, size_t size) {
        COPY_MEMORY cm;

        cm.pid = this->pid;
        cm.addr = addr;
        cm.buffer = buffer;
        cm.size = size;
        cm.yz = 1;

        if (ioctl(fd, OP_READ_MEM, &cm) != 0) {
            return false;
        }
        return true;
    }

    bool write(uintptr_t addr, void *buffer, size_t size) {
        COPY_MEMORY cm;

        cm.pid = this->pid;
        cm.addr = addr;
        cm.buffer = buffer;
        cm.size = size;
        cm.yz = 1;

        if(ioctl(fd, OP_WRITE_MEM, &cm) != 0) {
            return false;
        }
        return true;
    }

    template <typename T>
    T read(uintptr_t addr) {
        T res;
        if (this->read(addr, &res, sizeof(T)))
            return res;
        return {};
    }

    template <typename T>
    bool write(uintptr_t addr,T value) {
        return this->write(addr, &value, sizeof(T));
    }

    uintptr_t get_module_base(char* name) {
        MODULE_BASE mb;
        char buf[0x100];
        strcpy(buf,name);
        mb.pid = this->pid;
        mb.name = buf;

        if (ioctl(fd, OP_MODULE_BASE, &mb) != 0) {
            return 0;
        }
        return mb.base;
    }
};

c_driver driver = c_driver();

void getUTF8(UTF8 * buf, unsigned long namepy)
{
	UTF16 buf16[16] = { 0 };
	driver.read(namepy, buf16, 28);
	UTF16 *pTempUTF16 = buf16;
	UTF8 *pTempUTF8 = buf;
	UTF8 *pUTF8End = pTempUTF8 + 32;
	while (pTempUTF16 < pTempUTF16 + 28)
	{
		if (*pTempUTF16 <= 0x007F && pTempUTF8 + 1 < pUTF8End)
		{
			*pTempUTF8++ = (UTF8) * pTempUTF16;
		}
		else if (*pTempUTF16 >= 0x0080 && *pTempUTF16 <= 0x07FF && pTempUTF8 + 2 < pUTF8End)
		{
			*pTempUTF8++ = (*pTempUTF16 >> 6) | 0xC0;
			*pTempUTF8++ = (*pTempUTF16 & 0x3F) | 0x80;
		}
		else if (*pTempUTF16 >= 0x0800 && *pTempUTF16 <= 0xFFFF && pTempUTF8 + 3 < pUTF8End)
		{
			*pTempUTF8++ = (*pTempUTF16 >> 12) | 0xE0;
			*pTempUTF8++ = ((*pTempUTF16 >> 6) & 0x3F) | 0x80;
			*pTempUTF8++ = (*pTempUTF16 & 0x3F) | 0x80;
		}
		else
		{
			break;
		}
		pTempUTF16++;
	}
}
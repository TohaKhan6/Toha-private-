#include "draw.h"    //绘制套
#include "AndroidImgui.h"     //创建绘制套
#include "GraphicsManager.h" //获取 当前渲染模式
#include <iostream>
#include <sys/stat.h>

using namespace std;

bool isend=0,isyz=0,isyz2=0;

bool isrun(timer &drawfps)
{   
    if(!isyz||!isyz2) return 0;
    drawfps.SetFps(val[1]);
	drawfps.AotuFPS();
    drawBegin();
    graphics->NewFrame();
    bool res=menu();
    graphics->EndFrame();
    return res;
}

int main(int argc, char *argv[]) {
    
    bool wht=0;
    cout << "是否无后台(1/0):";
    cin >> wht;
    if (wht == 1) {
        pid_t pids = fork();
        if (pids > 0) {
            exit(0);
        }
    }


    ::graphics = GraphicsManager::getGraphicsInterface(GraphicsManager::VULKAN);
    //获取屏幕信息    
    ::screen_config(); 
    ::native_window_screen_x = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
    ::native_window_screen_y = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
    
    window = android::ANativeWindowCreator::Create("test", native_window_screen_x, native_window_screen_y);
    graphics->Init_Render(::window, native_window_screen_x, native_window_screen_y);
    native_window_screen_x = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
    native_window_screen_y = (::displayInfo.height > ::displayInfo.width ? ::displayInfo.height : ::displayInfo.width);
    
//    Touch::Init({(float)::abs_ScreenX, (float)::abs_ScreenY}, false);
 //   Touch::setOrientation(displayInfo.orientation);
    ::TouchScreenHandle();
    ::init_My_drawdata(); //初始化绘制数据

    static bool flag = true;
    while (flag) {
        drawBegin();
        graphics->NewFrame();       
        menu();        
        graphics->EndFrame();
    }
    
    // graphics->DeleteTexture(image);
    graphics->Shutdown();
    android::ANativeWindowCreator::Destroy(::window);
    return 0;
}

#include <imgui_internal.h>
#include <random>
#include <imgui.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <paths.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <linux/types.h>
#include <termios.h>
#include <time.h>
#include <pthread.h>
#include <thread>
#include <unistd.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <signal.h>
#include <touch.h>

using namespace std;
using std::string;

struct eventinfo {
	int ID;
	bool io = false;
	struct input_absinfo data;
};

//触控设备数据结构
struct events {
	int ID;
	bool io = false;
	bool infoio = false;
	eventinfo eventmsg[KEY_MAX + 1];
};

float x_proportion, y_proportion;
TouchFinger Fingers[10]; 
TouchFinger Finger1[10]; 

int GetEventCount()
{
	DIR *dir = opendir("/dev/input/");
	dirent *ptr = NULL;
	int count = 0;
	while ((ptr = readdir(dir)) != NULL)
	{
		if (strstr(ptr->d_name, "event"))
			count++;
	}
	return count;
}

int GetEventId()
{
	int EventCount = GetEventCount();
	int *fdArray = (int *)malloc(EventCount * 4 + 4);
	int result;

	for (int i = 0; i < EventCount; i++)
	{
		char temp[128];
		sprintf(temp, "/dev/input/event%d", i);
		fdArray[i] = open(temp, O_RDWR | O_NONBLOCK);
	}

	int k = 0;
	input_event ev;
	puts("\033[31m请点击屏幕\033[0m");
	while (1)
	{
		for (int i = 0; i < EventCount; i++)
		{
			memset(&ev, 0, sizeof(ev));
			read(fdArray[i], &ev, sizeof(ev));
			if (ev.type == EV_ABS)
			{
				// printf("id:%d\n", i);
				free(fdArray);
				return i;
			}
		}
		usleep(100);
	}
}

int fb,dev_fd;
int last_slot = -1;
bool touch_status = false;

int global_tracking_id = 0;


ImGuiIO* io;

void HandleTouchEvent() {
    int input_id = GetEventId();  // GetTouchEventNum();
	char devicepath[64];

	sprintf(devicepath, "/dev/input/event%d", input_id);
	printf("Eventpath: %s \n", devicepath);
	
    fb = open(devicepath, O_RDONLY | O_NONBLOCK);
	struct input_absinfo absX;
	struct input_absinfo absY;
	ioctl(fb, EVIOCGABS(ABS_MT_POSITION_X), &absX);
	ioctl(fb, EVIOCGABS(ABS_MT_POSITION_Y), &absY);
	float Width = absX.maximum + 1;
	float Height = absY.maximum + 1;
	
	int scr_x = displayInfo.width;
	int scr_y = displayInfo.height;
	
	if(scr_x > scr_y){
	    int t = scr_y;
	    scr_y = scr_x;
	    scr_x = t;
	}
    
    x_proportion = Width / scr_x;
    y_proportion = Height / scr_y;
    
    struct input_event in_ev, last_in_ev;

	int slot = 0, tracking_id = 0;
	int type, code, value;
	
	timer TouchingFPS;
    TouchingFPS.SetFps(1000);
    TouchingFPS.AotuFPS_init();
    TouchingFPS.setAffinity();
	while (!isend) {	
	    TouchingFPS.SetFps(1000);
		TouchingFPS.AotuFPS();
		
		while (true) {	
    	    io = &ImGui::GetIO();    
    	    read(fb, &in_ev, sizeof(in_ev));
    	    
    	    if (in_ev.code != SYN_REPORT) {
    			type = in_ev.type;
    			code = in_ev.code;
    			value = in_ev.value;
    			
    			auto& Finger = Fingers[slot];
    			auto& Finger2 =Finger1[slot];
    			Finger.time = in_ev.time;
    		
    			if (code == ABS_MT_POSITION_Y) {
    			    if (slot == 0) {
    			        if (displayInfo.orientation == 0)
        			        io->MousePos.y = value / y_proportion;
        			    else if(displayInfo.orientation == 1)
        			    	io->MousePos.x = value / y_proportion;
        				else
        			     	io->MousePos.x = scr_y - value / y_proportion;
        			}		    
    			    Finger.y = value;
    			    Finger2.x=value/x_proportion;
    		        Finger.status |= FINGER_Y_UPDATE;
    		    } else if(code == ABS_MT_POSITION_X) {
    		        if (slot == 0) {
    			        if (displayInfo.orientation == 0)
        			        io->MousePos.x = value / x_proportion;
        			    else if(displayInfo.orientation == 1)
        			    	io->MousePos.y = scr_x - value / x_proportion;
        				else
    				        io->MousePos.y = value / x_proportion;
    			    }		  		    
    		        Finger.x = value;
    		        Finger2.y=value/y_proportion;
    		        Finger.status |= FINGER_X_UPDATE;		
    			} else if(code == ABS_MT_TRACKING_ID) {
    			    if (value == -1){
    			        if(slot == 0)
    			            io->MouseDown[0] = false;
    			        Finger2.x=-1;
    		            Finger2.y=-1;
    			        Finger.status = FINGER_UP;
    			    } else {
    			        if(slot == 0)
    			            io->MouseDown[0] = true;
    			        Finger.tracking_id = global_tracking_id;
    					global_tracking_id ++;				
    			    }		  			    
    			} else if(code == ABS_MT_SLOT) {
    			    slot = value;
    			}			
    		} else {        
    		    break;	
    		}
		}
	}
}

void TouchScreenHandle()
{
    thread touch_thread(HandleTouchEvent);
    touch_thread.detach();
}

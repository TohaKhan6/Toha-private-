int getMaterialName(char *name, char *dealname)	// 车
{
  if (swh[13])
  {
    if (mystrstr(name, "VH_Motorcycle") != -1)
    {
      strcpy(dealname, "摩托车");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-1.png");
      return 1;
    }
    if (mystrstr(name, "VH_Scooter") != -1)
    {
      strcpy(dealname, "电单车");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-3.png");
      return 1;			// 小绵羊车
    }
    if (mystrstr(name, "VH_MotorcycleCart") != -1)
    {
      strcpy(dealname, "三轮摩托");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-2.png");
      return 1;			// 三轮摩托车
    }
  
    if (mystrstr(name, "VH_Tuk") != -1)
    {
      strcpy(dealname, "三轮摩托");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-2.png");
      return 1;			// 三轮摩托
    }
  
    if (mystrstr(name, "Buggy") != -1)
    {
      strcpy(dealname, "蹦子");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-4.png");
      return 1;			// 蹦蹦BuggyMirado
    }
  
    if (mystrstr(name, "Mirado") != -1)
    {
      strcpy(dealname, "敞篷跑");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-5.png");
      return 1;			// 跑车
    }
  
    if (mystrstr(name, "CoupeRB") != -1)
    {
      strcpy(dealname, "超跑");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-5.png");
      return 1;			// 跑车
    }
  
    if (mystrstr(name, "Dacia") != -1)
    {
      strcpy(dealname, "小轿");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-6.png");
      return 1;			// 轿车
    }
  
    if (mystrstr(name, "PickUp_02_C") != -1)
    {
      strcpy(dealname, "皮卡");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-7.png");
      return 1;			// 皮卡车
    }
  
    if (mystrstr(name, "Rony") != -1)
    {
      strcpy(dealname, "吉普");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-8.png");
      return 1;			// 火货车
    }
  
    if (mystrstr(name, "_StationWagon_C") != -1)
    {
      strcpy(dealname, "旅行");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-8.png");
      return 1;			// 吉普
    }
  
    if (mystrstr(name, "UAZ") != -1)
    {
      strcpy(dealname, "吉普");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-8.png");
      return 1;			// 吉普
    }
  
    if (mystrstr(name, "PG117") != -1)
    {
      strcpy(dealname, "快艇");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-9.png");
      return 1;			// 快艇
    }
  
    if (mystrstr(name, "AquaRail") != -1)
    {
      strcpy(dealname, "冲锋艇");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-10.png");
      return 1;			// 冲锋艇
    }
  
    if (mystrstr(name, "MiniBus") != -1)
    {
      strcpy(dealname, "面包车");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-11.png");
      return 1;			// 面包车
    }
  
    if (mystrstr(name, "BP_Chariot_BattleItemHandle_C") != -1)
    {
      strcpy(dealname, "龙腾战车");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-11.png");
      return 1;			// 面包车
    }
  
    if (mystrstr(name, "VH_BRDM") != -1)
    {
      strcpy(dealname, "装甲车");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-12.png");
      return 1;			// 两栖装甲车
    }
  
    if (mystrstr(name, "LadaNiva") != -1)
    {
      strcpy(dealname, "拉达尼瓦");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-13.png");
      return 1;			// 拉达尼瓦
    }
  
    if (mystrstr(name, "AH6") != -1)
    {
      strcpy(dealname, "直升机");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-1.png");
      return 1;			// 直升机
    }
  
    if (mystrstr(name, "_4SportCar_C") != -1)
    {
      strcpy(dealname, "敞篷跑");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-1.png");
      return 1;			// 直升机
    }
  
    if (mystrstr(name, "_Bigfoot_C") != -1)
    {
      strcpy(dealname, "大脚车");
      wzclor = ImColor(255, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Vehicle-1.png");
      return 1;			// 直升机
    }
  }
  if (swh[15])
  {
    if (mystrstr(name, "AirDropListWrapperActor_Pickup_C") != -1)
    {
      strcpy(dealname, "空投");
      wzclor = ImColor(0, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Airdrop-2.png");
      return 3;			// 空投
    }
  
    if (mystrstr(name, "CG017") != -1)
    {
      strcpy(dealname, "空投");
      wzclor = ImColor(0, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Airdrop-2.png");
      
      return 3;			// 空投
    }
  
    if (mystrstr(name, "BP_AirDropBox_C") != -1)
    {
      strcpy(dealname, "空投");
      wzclor = ImColor(0, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Airdrop-2.png");
      
      return 3;
    }
  }
  if (swh[14])
  {
    if (mystrstr(name, "DeadInventoryBox_C") != -1)
    {
      strcpy(dealname, "盒子");
      wzclor = ImColor(0, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Airdrop-2.png");
      
      return 3;
    }
    if (mystrstr(name, "_TrainingBoxListWrapper_C") != -1)
    {
      strcpy(dealname, "盒子");
      wzclor = ImColor(0, 255, 0, 255);
      //Image wztp = loadImage("/sdcard/Bor/Airdrop-2.png");
      return 3;
    }
    if (mystrstr(name, "PickUpListWrapperActor") != -1)
    {
		strcpy(dealname, "盒子");
		wzclor = ImColor(0, 255, 0, 255);
		//Image wztp = loadImage("/sdcard/Bor/Airdrop-2.png");
			
		return 3;
	}
  }
  if (swh[12])
  {      
    if (mystrstr(name, "ojGrenade_BP_C") != -1)//手雷
    {
        strcpy(dealname, "小心手榴弹");
        wzclor = ImColor(255, 0, 0, 255);
        return 4;
    }
    if (mystrstr(name, "ojBurn_BP_C") != -1) {
        strcpy(dealname, "小心燃烧弹");
        wzclor = ImColor(255, 0, 0, 255);
        return 4;
    }
  }
  return 0;
}

char *GetHolGunItem(int BoxId)
{
    switch (BoxId)
    {
        //突击步枪
        case 0:
            return "空手";
        break;
        case 101008:
            return "M762";
        break;
        case 101001:
            return "AKM";
        break;
        case 101004:
            return "M416";
        break;
        case 101003:
            return "SCAR-L";
        break;
        case 101002:
            return "M16A4";
        break;
        case 101009:
            return "Mk47";
        break;
        case 101006:
            return "AUG";
        break;
        case 101005:
            return "Groza";
        break;
        case 101010:
            return "G36C";
        break;
        case 101007:
            return "QBZ";
        break;
        case 101011:
            return "AC-VAL";
        break;
        case 101012:
            return "蜜獾突击步枪";
        break;
        //连狙
        case 103009:
            return "SLR";
        break;
        case 103005:
            return "VSS";
        break;
        case 103006:
            return "Mini14";
        break;
        case 103010:
            return "QBU";
        break;
        case 103004:
            return "SKS";
        break;
        case 103007:
            return "MK14";
        break;
        case 103014:
            return "MK20-H";
        break;
        case 103013:
            return "M417";
        break;
        //连狙
        case 103012:
            return "AMR";
        break;
        case 103003:
            return "AWM";
        break;
        case 103002:
            return "M24";
        break;
        case 103011:
            return "莫甘娜辛";
        break;
        case 103001:
            return "Kar98K";
        break;
        case 103008:
            return "Win94";
        break;
        //机关枪
        case 105001:
            return "M249";
        break;
        case 105002:
            return "DP-28";
        case 105010:
            return "MG3";
        break;
        case 107001:
            return "十字弩";
        break;
        case 107007:
            return "爆炸猎弓";
        break;
        //冲锋枪
        case 102001:
            return "UZI";
        break;
        case 102003:
            return "Vector";
        break;
        case 100103:
            return "PP-19";
        break;
        case 102007:
            return "MP5K";
        break;
        case 102002:
            return "UMP-45";
        break;
        case 102004:
            return "汤姆逊";
        break;
        case 102105:
            return "P90";
        break;
        case 102005:
            return "野牛";
        break;
        //霰弹枪
        case 104001:
            return "S686";
        break;
        case 104002:
            return "S1897";
        break;
        case 104003:
            return "S12K";
        break;
        case 104004:
            return "DBS";
        break;
        case 104100:
            return "SPAS-12";
        break;
        //投掷爆炸物
        case 602004:
            return "手榴弹";
        break;
        case 602003:
            return "燃烧瓶";
        break;
        case 602002:
            return "烟雾弹";
        break;
        case 602001:
            return "震撼弹";
        break;
        //近战武器
        case 108003:
            return "镰刀";
        break;
        case 108002:
            return "撬棍";
        break;
        case 108001:
            return "大砍刀";
        break;
        case 108004:
            return "平底锅";
        break;
        case 9808001:
            return "P92手枪(破损)";
            break;
        case 9808002:
            return "P92手枪(修复)";
            break;
        case 9808003:
            return "P92手枪(完好)";
            break;
        case 9808008:
            return "P1911手枪(破损)";
            break;
        case 9808009:
            return "P1911手枪(修复)";
            break;
        case 9808010:
            return "P1911手枪(完好)";
            break;
        case 9808015:
            return "R1895手枪(破损)";
            break;
        case 9808016:
            return "R1895手枪(修复)";
            break;
        case 9808017:
            return "R1895手枪(完好)";
            break;
        case 9808022:
            return "P18C手枪(破损)";
            break;
        case 9808023:
            return "P18C手枪(修复)";
            break;
        case 9808024:
            return "P18C手枪(完好)";
            break;
        case 9808029:
            return "R45手枪(破损)";
            break;
        case 9808030:
            return "R45手枪(修复)";
            break;
        case 9808031:
            return "R45手枪(完好)";
            break;
        case 9808036:
            return "短管霰弹枪(破损)";
            break;
        case 9808037:
            return "短管霰弹枪(修复)";
            break;
        case 9808038:
            return "短管霰弹枪(完好)";
            break;
        case 9808043:
            return "蝎式手枪(修复)";
            break;
        case 9808044:
            return "蝎式手枪(完好)";
            break;
        case 9808045:
            return "蝎式手枪(改进)";
            break;
        case 9808046:
            return "蝎式手枪(破损)";
            break;
        case 9808050:
            return "沙漠之鹰手枪(修复)";
            break;
        case 9808051:
            return "沙漠之鹰手枪(完好)";
            break;
        case 9808052:
            return "沙漠之鹰手枪(改进)";
            break;
        case 9808053:
            return "沙漠之鹰手枪(破损)";
            break;
        case 9808057:
            return "TMP-9手枪(修复)";
            break;
        case 9808058:
            return "TMP-9手枪(完好)";
            break;
        case 9808059:
            return "TMP-9手枪(改进)";
            break;
        case 9808060:
            return "空投信号枪";
            break;
        case 9808061:
            return "TMP-9手枪(破损)";
            break;
        case 9809001:
            return "十字弩(破损)";
            break;
        case 9809002:
            return "十字弩(修复)";
            break;
        case 9809003:
            return "十字弩(完好)";
            break;
        case 9809009:
            return "爆炸猎弓(骑警Boss)";
            break;
        case 9809010:
            return "爆炸猎弓·杰西";
            break;
        case 9810001:
            return "S686霰弹枪(破损)";
            break;
        case 9810002:
            return "S686霰弹枪(修复)";
            break;
        case 9810003:
            return "S686霰弹枪(完好)";
            break;
        case 9810008:
            return "S1897霰弹枪(破损)";
            break;
        case 9810009:
            return "S1897霰弹枪(修复)";
            break;
        case 9810010:
            return "S1897霰弹枪(完好)";
            break;
        case 9810015:
            return "S12K霰弹枪(精制)";
            break;
        case 9810016:
            return "S12K霰弹枪(修复)";
            break;
        case 9810017:
            return "S12K霰弹枪(完好)";
            break;
        case 9810018:
            return "S12K霰弹枪(改进)";
            break;
        case 9810022:
            return "DBS霰弹枪(修复)";
            break;
        case 9810023:
            return "DBS霰弹枪(完好)";
            break;
        case 9810024:
            return "DBS霰弹枪(改进)";
            break;
        case 9810025:
            return "DBS霰弹枪(精制)";
            break;
        case 9810029:
            return "SPAS-12霰弹枪(修复)";
            break;
        case 9810030:
            return "SPAS-12霰弹枪(完好)";
            break;
        case 9810031:
            return "SPAS-12霰弹枪(改进)";
            break;
        case 9810032:
            return "SPAS-12霰弹枪(精制)";
            break;
        case 9810036:
            return "AA12-G霰弹枪(修复)";
            break;
        case 9810037:
            return "AA12-G霰弹枪(完好)";
            break;
        case 9810038:
            return "AA12-G霰弹枪(改进)";
            break;
        case 9810041:
            return "AA12-G霰弹枪(精制)";
            break;
        case 9811001:
            return "UZI冲锋枪(破损)";
            break;
        case 9811002:
            return "UZI冲锋枪(修复)";
            break;
        case 9811003:
            return "UZI冲锋枪(完好)";
            break;
        case 9811004:
            return "UZI冲锋枪(改进)";
            break;
        case 9811008:
            return "UMP45冲锋枪(破损)";
            break;
        case 9811009:
            return "UMP45冲锋枪(修复)";
            break;
        case 9811010:
            return "UMP45冲锋枪(完好)";
            break;
        case 9811011:
            return "UMP45冲锋枪(改进)";
            break;
        case 9811015:
            return "Vector冲锋枪(卓越)";
            break;
        case 9811016:
            return "Vector冲锋枪(完好)";
            break;
        case 9811017:
            return "Vector冲锋枪(改进)";
            break;
        case 9811018:
            return "Vector冲锋枪(精制)";
            break;
        case 9811019:
            return "Vector冲锋枪(卓越)";
            break;
        case 9811020:
            return "Vector冲锋枪(黑鹰)";
            break;
        case 9811021:
            return "Vector冲锋枪(铁爪)";
            break;
        case 9811022:
            return "汤姆逊冲锋枪(破损)";
            break;
        case 9811023:
            return "汤姆逊冲锋枪(修复)";
            break;
        case 9811024:
            return "汤姆逊冲锋枪(完好)";
            break;
        case 9811025:
            return "汤姆逊冲锋枪(改进)";
            break;
        case 9811029:
            return "野牛冲锋枪(破损)";
            break;
        case 9811030:
            return "野牛冲锋枪(修复)";
            break;
        case 9811031:
            return "野牛冲锋枪(完好)";
            break;
        case 9811036:
            return "MP5K冲锋枪(卓越)";
            break;
        case 9811037:
            return "MP5K冲锋枪(完好)";
            break;
        case 9811038:
            return "MP5K冲锋枪(改进)";
            break;
        case 9811039:
            return "MP5K冲锋枪(精制)";
            break;
        case 9811040:
            return "MP5K冲锋枪(卓越)";
            break;
        case 9811041:
            return "MP5K冲锋枪(黑鹰)";
            break;
        case 9811042:
            return "MP5K冲锋枪(铁爪)";
            break;
        case 9811043:
            return "AKS-74U冲锋枪(卓越)";
            break;
        case 9811044:
            return "AKS-74U冲锋枪(完好)";
            break;
        case 9811045:
            return "AKS-74U冲锋枪(改进)";
            break;
        case 9811046:
            return "AKS-74U冲锋枪(精制)";
            break;
        case 9811047:
            return "AKS-74U冲锋枪(卓越)";
            break;
        case 9811048:
            return "AKS-74U冲锋枪(铁爪)";
            break;
        case 9811049:
            return "AKS-74U冲锋枪(黑鹰)";
            break;
        case 9811050:
            return "P90冲锋枪(卓越)";
            break;
        case 9811051:
            return "P90冲锋枪(完好)";
            break;
        case 9811052:
            return "P90冲锋枪(改进)";
            break;
        case 9811053:
            return "P90冲锋枪(精制)";
            break;
        case 9811054:
            return "P90冲锋枪(卓越)";
            break;
        case 9811055:
            return "P90冲锋枪(黑鹰)";
            break;
        case 9811056:
            return "P90冲锋枪(铁爪)";
            break;
        case 9812002:
            return "AKM突击步枪(卓越)";
            break;
        case 9812003:
            return "AKM突击步枪(完好)";
            break;
        case 9812004:
            return "AKM突击步枪(改进)";
            break;
        case 9812005:
            return "AKM突击步枪(精制)";
            break;
        case 9812006:
            return "AKM突击步枪(卓越)";
            break;
        case 9812007:
            return "AKM突击步枪(黑鹰)";
            break;
        case 9812008:
            return "AKM突击步枪(铁爪)";
            break;
        case 9812009:
            return "M16A4突击步枪(破损)";
            break;
        case 9812010:
            return "M16A4突击步枪(修复)";
            break;
        case 9812011:
            return "M16A4突击步枪(完好)";
            break;
        case 9812012:
            return "M16A4突击步枪(改进)";
            break;
        case 9812015:
            return "SCAR-L突击步枪(卓越)";
            break;
        case 9812016:
            return "SCAR-L突击步枪(完好)";
            break;
        case 9812017:
            return "SCAR-L突击步枪(改进)";
            break;
        case 9812018:
            return "SCAR-L突击步枪(精制)";
            break;
        case 9812019:
            return "SCAR-L突击步枪(卓越)";
            break;
        case 9812020:
            return "SCAR-L突击步枪(黑鹰)";
            break;
        case 9812021:
            return "SCAR-L突击步枪(铁爪)";
            break;
        case 9812022:
            return "M416突击步枪(铁爪)";
            break;
        case 9812023:
            return "M416突击步枪(卓越)";
            break;
        case 9812024:
            return "M416突击步枪(完好)";
            break;
        case 9812025:
            return "M416突击步枪(改进)";
            break;
        case 9812026:
            return "M416突击步枪(精制)";
            break;
        case 9812027:
            return "M416突击步枪(卓越)";
            break;
        case 9812028:
            return "M416突击步枪(黑鹰)";
            break;
        case 9812029:
            return "GROZA突击步枪(卓越)";
            break;
        case 9812030:
            return "GROZA突击步枪(改进)";
            break;
        case 9812031:
            return "GROZA突击步枪(精制)";
            break;
        case 9812032:
            return "GROZA突击步枪(卓越)";
            break;
        case 9812033:
            return "GROZA突击步枪(黑鹰)";
            break;
        case 9812034:
            return "GROZA突击步枪(铁爪)";
            break;
        case 9812036:
            return "AUG突击步枪(卓越)";
            break;
        case 9812037:
            return "AUG突击步枪(改进)";
            break;
        case 9812038:
            return "AUG突击步枪(精制)";
            break;
        case 9812039:
            return "AUG突击步枪(卓越)";
            break;
        case 9812040:
            return "AUG突击步枪(黑鹰)";
            break;
        case 9812041:
            return "AUG突击步枪(铁爪)";
            break;
        case 9812043:
            return "QBZ突击步枪(卓越)";
            break;
        case 9812044:
            return "QBZ突击步枪(完好)";
            break;
        case 9812045:
            return "QBZ突击步枪(改进)";
            break;
        case 9812046:
            return "QBZ突击步枪(精制)";
            break;
        case 9812047:
            return "QBZ突击步枪(卓越)";
            break;
        case 9812048:
            return "QBZ突击步枪(黑鹰)";
            break;
        case 9812049:
            return "QBZ突击步枪(铁爪)";
            break;
        case 9812050:
            return "M762突击步枪(卓越)";
            break;
        case 9812051:
            return "M762突击步枪(完好)";
            break;
        case 9812052:
            return "M762突击步枪(改进)";
            break;
        case 9812053:
            return "M762突击步枪(精制)";
            break;
        case 9812054:
            return "M762突击步枪(卓越)";
            break;
        case 9812055:
            return "M762突击步枪(黑鹰)";
            break;
        case 9812056:
            return "M762突击步枪(铁爪)";
            break;
        case 9812057:
            return "Mk47突击步枪(破损)";
            break;
        case 9812058:
            return "Mk47突击步枪(修复)";
            break;
        case 9812059:
            return "Mk47突击步枪(完好)";
            break;
        case 9812060:
            return "Mk47突击步枪(改进)";
            break;
        case 9812064:
            return "G36C突击步枪(卓越)";
            break;
        case 9812065:
            return "G36C突击步枪(完好)";
            break;
        case 9812066:
            return "G36C突击步枪(改进)";
            break;
        case 9812067:
            return "G36C突击步枪(精制)";
            break;
        case 9812068:
            return "G36C突击步枪(卓越)";
            break;
        case 9812069:
            return "G36C突击步枪(黑鹰)";
            break;
        case 9812070:
            return "G36C突击步枪(铁爪)";
            break;
        case 9812071:
            return "AC-VAL突击步枪(破损)";
            break;
        case 9812072:
            return "AC-VAL突击步枪(修复)";
            break;
        case 9812073:
            return "AC-VAL突击步枪(完好)";
            break;
        case 9812074:
            return "AC-VAL突击步枪(改进)";
            break;
        case 9812078:
            return "蜜獾突击步枪(卓越)";
            break;
        case 9812079:
            return "蜜獾突击步枪(完好)";
            break;
        case 9812080:
            return "蜜獾突击步枪(改进)";
            break;
        case 9812081:
            return "蜜獾突击步枪(精制)";
            break;
        case 9812082:
            return "蜜獾突击步枪(卓越)";
            break;
        case 9812083:
            return "蜜獾突击步枪(黑鹰)";
            break;
        case 9812084:
            return "蜜獾突击步枪(铁爪)";
            break;
        case 9812085:
            return "FAMAS突击步枪(卓越)";
            break;
        case 9812086:
            return "FAMAS突击步枪(完好)";
            break;
        case 9812087:
            return "FAMAS突击步枪(改进)";
            break;
        case 9812088:
            return "FAMAS突击步枪(精制)";
            break;
        case 9812089:
            return "FAMAS突击步枪(卓越)";
            break;
        case 9812090:
            return "FAMAS突击步枪(黑鹰)";
            break;
        case 9812091:
            return "FAMAS突击步枪(铁爪)";
            break;
        case 9812092:
            return "M416突击步枪·卡德尔";
            break;
        case 9813001:
            return "M249轻机枪(卓越)";
            break;
        case 9813002:
            return "M249轻机枪(改进)";
            break;
        case 9813003:
            return "M249轻机枪(精制)";
            break;
        case 9813004:
            return "M249轻机枪(卓越)";
            break;
        case 9813005:
            return "M249轻机枪(黑鹰)";
            break;
        case 9813006:
            return "M249轻机枪(铁爪)";
            break;
        case 9813008:
            return "DP-28轻机枪(破损)";
            break;
        case 9813009:
            return "DP-28轻机枪(修复)";
            break;
        case 9813010:
            return "DP-28轻机枪(完好)";
            break;
        case 9813022:
            return "MG3轻机枪(卓越)";
            break;
        case 9813023:
            return "MG3轻机枪(改进)";
            break;
        case 9813024:
            return "MG3轻机枪(精制)";
            break;
        case 9813025:
            return "MG3轻机枪(卓越)";
            break;
        case 9813026:
            return "MG3轻机枪(黑鹰)";
            break;
        case 9813027:
            return "MG3轻机枪(铁爪)";
            break;
        case 9813029:
            return "PKM轻机枪(卓越)";
            break;
        case 9813030:
            return "PKM轻机枪(改进)";
            break;
        case 9813031:
            return "PKM轻机枪(精制)";
            break;
        case 9813032:
            return "PKM轻机枪(卓越)";
            break;
        case 9813033:
            return "PKM轻机枪(黑鹰)";
            break;
        case 9813034:
            return "PKM轻机枪(铁爪)";
            break;
        case 9814001:
            return "Kar98K狙击枪(修复)";
            break;
        case 9814002:
            return "Kar98K狙击枪(完好)";
            break;
        case 9814003:
            return "Kar98K狙击枪(改进)";
            break;
        case 9814008:
            return "M24狙击枪(卓越)";
            break;
        case 9814009:
            return "M24狙击枪(完好)";
            break;
        case 9814010:
            return "M24狙击枪(改进)";
            break;
        case 9814011:
            return "M24狙击枪(精制)";
            break;
        case 9814012:
            return "M24狙击枪(卓越)";
            break;
        case 9814013:
            return "M24狙击枪(黑鹰)";
            break;
        case 9814014:
            return "M24狙击枪(铁爪)";
            break;
        case 9814015:
            return "AWM狙击枪(卓越)";
            break;
        case 9814016:
            return "AWM狙击枪(改进)";
            break;
        case 9814017:
            return "AWM狙击枪(精制)";
            break;
        case 9814018:
            return "AWM狙击枪(卓越)";
            break;
        case 9814019:
            return "AWM狙击枪(黑鹰)";
            break;
        case 9814020:
            return "AWM狙击枪(铁爪)";
            break;
        case 9814022:
            return "莫辛纳甘狙击枪(破损)";
            break;
        case 9814023:
            return "莫辛纳甘狙击枪(修复)";
            break;
        case 9814024:
            return "莫辛纳甘狙击枪(完好)";
            break;
        case 9814029:
            return "Win94狙击枪(破损)";
            break;
        case 9814030:
            return "Win94狙击枪(修复)";
            break;
        case 9814031:
            return "Win94狙击枪(完好)";
            break;
        case 9814036:
            return "AMR狙击枪(卓越)";
            break;
        case 9814037:
            return "AMR狙击枪(改进)";
            break;
        case 9814038:
            return "AMR狙击枪(精制)";
            break;
        case 9814039:
            return "AMR狙击枪(卓越)";
            break;
        case 9814040:
            return "AMR狙击枪(黑鹰)";
            break;
        case 9814041:
            return "AMR狙击枪(铁爪)";
            break;
        case 9814043:
            return "M200狙击枪(卓越)";
            break;
        case 9814044:
            return "M200狙击枪(完好)";
            break;
        case 9814045:
            return "M200狙击枪(改进)";
            break;
        case 9814046:
            return "M200狙击枪(精制)";
            break;
        case 9814047:
            return "M200狙击枪(卓越)";
            break;
        case 9814048:
            return "M200狙击枪(黑鹰)";
            break;
        case 9814049:
            return "M200狙击枪(铁爪)";
            break;
        case 9814050:
            return "SVD狙击枪(改进)";
            break;
        case 9814051:
            return "SVD狙击枪(精制)";
            break;
        case 9814052:
            return "SVD狙击枪(卓越)";
            break;
        case 9814053:
            return "SVD狙击枪(卓越)";
            break;
        case 9815001:
            return "SKS射手步枪(卓越)";
            break;
        case 9815002:
            return "SKS射手步枪(完好)";
            break;
        case 9815003:
            return "SKS射手步枪(改进)";
            break;
        case 9815004:
            return "SKS射手步枪(精制)";
            break;
        case 9815005:
            return "SKS射手步枪(卓越)";
            break;
        case 9815006:
            return "SKS射手步枪(黑鹰)";
            break;
        case 9815007:
            return "SKS射手步枪(铁爪)";
            break;
        case 9815008:
            return "VSS射手步枪(破损)";
            break;
        case 9815009:
            return "VSS射手步枪(修复)";
            break;
        case 9815010:
            return "VSS射手步枪(完好)";
            break;
        case 9815015:
            return "Mini14射手步枪(破损)";
            break;
        case 9815016:
            return "Mini14射手步枪(修复)";
            break;
        case 9815017:
            return "Mini14射手步枪(完好)";
            break;
        case 9815018:
            return "Mini14射手步枪(改进)";
            break;
        case 9815022:
            return "Mk14射手步枪(卓越)";
            break;
        case 9815023:
            return "Mk14射手步枪(完好)";
            break;
        case 9815024:
            return "Mk14射手步枪(改进)";
            break;
        case 9815025:
            return "Mk14射手步枪(精制)";
            break;
        case 9815026:
            return "Mk14射手步枪(卓越)";
            break;
        case 9815027:
            return "Mk14射手步枪(黑鹰)";
            break;
        case 9815028:
            return "Mk14射手步枪(铁爪)";
            break;
        case 9815029:
            return "SLR射手步枪(卓越)";
            break;
        case 9815030:
            return "SLR射手步枪(完好)";
            break;
        case 9815031:
            return "SLR射手步枪(改进)";
            break;
        case 9815032:
            return "SLR射手步枪(精制)";
            break;
        case 9815033:
            return "SLR射手步枪(卓越)";
            break;
        case 9815034:
            return "SLR射手步枪(黑鹰)";
            break;
        case 9815035:
            return "SLR射手步枪(铁爪)";
            break;
        case 9815036:
            return "QBU射手步枪(破损)";
            break;
        case 9815037:
            return "QBU射手步枪(修复)";
            break;
        case 9815038:
            return "QBU射手步枪(完好)";
            break;
        case 9815039:
            return "QBU射手步枪(改进)";
            break;
        case 9815043:
            return "M417射手步枪(卓越)";
            break;
        case 9815044:
            return "M417射手步枪(完好)";
            break;
        case 9815045:
            return "M417射手步枪(改进)";
            break;
        case 9815046:
            return "M417射手步枪(精制)";
            break;
        case 9815047:
            return "M417射手步枪(卓越)";
            break;
        case 9815048:
            return "M417射手步枪(黑鹰)";
            break;
        case 9815049:
            return "M417射手步枪(铁爪)";
            break;
        case 9815050:
            return "MK20-H射手步枪(卓越)";
            break;
        case 9815051:
            return "MK20-H射手步枪(完好)";
            break;
        case 9815052:
            return "MK20-H射手步枪(改进)";
            break;
        case 9815053:
            return "MK20-H射手步枪(精制)";
            break;
        case 9815054:
            return "MK20-H射手步枪(卓越)";
            break;
        case 9815055:
            return "MK20-H射手步枪(黑鹰)";
            break;
        case 9815056:
            return "MK20-H射手步枪(铁爪)";
            break;
        case 9815064:
            return "MK12射手步枪(卓越)";
            break;
        case 9815065:
            return "MK12射手步枪(完好)";
            break;
        case 9815066:
            return "MK12射手步枪(改进)";
            break;
        case 9815067:
            return "MK12射手步枪(精制)";
            break;
        case 9815068:
            return "MK12射手步枪(卓越)";
            break;
        case 9815069:
            return "MK12射手步枪(黑鹰)";
            break;
        case 9815070:
            return "MK12射手步枪(铁爪)";
            break;
        default:
            return "暂未收录";
        break;
    }
    return nullptr;
}

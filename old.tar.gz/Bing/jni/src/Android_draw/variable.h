#include <random>
int val[50]={};
bool swh[50];
bool init=0,wzkg=0;
uintptr_t libue4addr,matrixaddr,gnameaddr;

long int libbase, libbase2,Module2s, Gnamk9jie, Uworld, Arrayaddr, Matrix, oneself, Objaddr,handheld, Mesh, human, Bone, Uleve, 自身动作;
int Myteam, MyWeapon;
char PlayerName[100];
int AddCount;
int PlayerCount;
uintptr_t CountAddr, ArrayAddr, UworldAddr, MatrixAddr, GnameAddr;
int countddr;

float matrix[16];
string imeienc;
FILE *numSave = nullptr;
ImVec2 ImagePos = {0, 0};
int MenuTab = 1;
bool IsDown = false, MemuSwitch = true, BallSwitch = false;
float timernow = 0.0f;
float breathSpeed = 0.25f;
ImColor BoxColor = ImColor(255,0,0,200);
ImColor BotBoxColor = ImColor(0,255,0,200);
ImColor LineColor = ImColor(255,0,0,200);
ImColor BotLineColor = ImColor(0,255,0,200);
ImColor BoneColor = ImColor(255,0,0,200);
ImColor BotBoneColor = ImColor(0,255,0,200);
ImColor RightColor = ImColor(255,100,100,255);
ImColor BotRightColor = ImColor(255,255,255,200);    
ImColor wzclor = ImColor(225, 255, 255);

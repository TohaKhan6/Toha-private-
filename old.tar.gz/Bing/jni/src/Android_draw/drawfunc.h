using namespace std;
void OffScreen(ImDrawList *Draw, Vector2A Obj, float camear, ImColor color, float Radius)
{
	ImRect screen_rect = {0.0f, 0.0f, (float)displayInfo.width, (float)displayInfo.height};
	auto screen_center = screen_rect.GetCenter();
	auto angle = atan2(screen_center.y - Obj.Y, screen_center.x - Obj.X);
	angle += camear > 0 ? M_PI : 0.0f;
	ImVec2 arrow_center {
			screen_center.x + Radius * cosf(angle),
			screen_center.y + Radius * sinf(angle)
	};
	std::array<ImVec2, 4>points {
			ImVec2(-22.0f, -8.6f),
			ImVec2(0.0f, 0.0f),
			ImVec2(-22.0f, 8.6f),
			ImVec2(-18.0f, 0.0f)
	};
	for (auto & point : points)
	{
		auto x = point.x * 1.155f;
		auto y = point.y * 1.155f;
		point.x = arrow_center.x + x * cosf(angle) - y * sinf(angle);
		point.y = arrow_center.y + x * sinf(angle) + y * cosf(angle);
	}
	float alpha = 1.0f;
	if (camear > 0)
	{
		constexpr float nearThreshold = 200 * 200;
		ImVec2 screen_outer_diff = {
				Obj.X < 0 ? abs(Obj.X) : (Obj.X > screen_rect.Max.x ? Obj.X - screen_rect.Max.x : 0.0f),
				Obj.Y < 0 ? abs(Obj.Y) : (Obj.Y > screen_rect.Max.y ? Obj.Y - screen_rect.Max.y : 0.0f),
		};
		float distance = static_cast<float>(pow(screen_outer_diff.x, 2) + pow(screen_outer_diff.y, 2));
		alpha = camear < 0 ? 1.0f : (distance / nearThreshold);
	}
	ImColor arrowColor = color;
	arrowColor.Value.w = std::min(alpha, 1.0f);
	Draw->AddTriangleFilled(points[0], points[1], points[3], arrowColor);
	Draw->AddTriangleFilled(points[2], points[1], points[3], arrowColor);
	Draw->AddQuad(points[0], points[1], points[2], points[3], ImColor(0.0f, 0.0f, 0.0f, alpha), 1.335f);
}

bool getisDie(int state, float health) {
    return health == 0;
}

static void DrawRadar(float Angle, float x, float y, ImColor color) {
    float w = 45.0f / 2 / 1.5f;
    float b = 22.5f;
    if (Angle <= b || Angle >= 360 - b) {
        ImGui::GetForegroundDrawList()->AddLine({x - w, y + w}, {x, y - w}, color, 1);
        ImGui::GetForegroundDrawList()->AddLine({x, y - w}, {x + w, y + w}, color, 1);
    } else if (Angle >= 90 - b && Angle <= 90 + b) {
        ImGui::GetForegroundDrawList()->AddLine({x - w, y - w}, {x + w, y}, color, 1);
        ImGui::GetForegroundDrawList()->AddLine({x + w, y},  {x - w, y + w},  color, 1);
    } else if (Angle >= 180 - b && Angle <= 180 + b) {
        ImGui::GetForegroundDrawList()->AddLine({x - w, y - w},  {x, y + w},  color, 1);
        ImGui::GetForegroundDrawList()->AddLine({x, y + w},  {x + w, y - w},  color, 1);
    } else if (Angle >= 270 - b && Angle <= 270 + b) {
        ImGui::GetForegroundDrawList()->AddLine({x + w, y - w},  {x - w, y},  color, 1);
        ImGui::GetForegroundDrawList()->AddLine({x - w, y},  {x + w, y + w},  color, 1);
    } else if (Angle >= 45 - b && Angle <= 45 + b) {
        ImGui::GetForegroundDrawList()->AddLine({x + w, y - w},  {x - w, y},  color, 1);
        ImGui::GetForegroundDrawList()->AddLine({x + w, y - w},  {x, y + w},  color, 1);
    } else if (Angle >= 135 - b && Angle <= 135 + b) {
        ImGui::GetForegroundDrawList()->AddLine({x + w, y + w},  {x - w, y},  color, 1);
        ImGui::GetForegroundDrawList()->AddLine({x + w, y + w},  {x, y - w},  color, 1);
    } else if (Angle >= 225 - b && Angle <= 225 + b) {
        ImGui::GetForegroundDrawList()->AddLine({x - w, y + w}, {x, y - w},  color, 1);
        ImGui::GetForegroundDrawList()->AddLine({x - w, y + w},  {x + w, y},  color, 1);
    } else if (Angle >= 315 - b && Angle <= 315 + b) {
        ImGui::GetForegroundDrawList()->AddLine({x - w, y - w},  {x + w, y},  color, 1);
        ImGui::GetForegroundDrawList()->AddLine({x - w, y - w},  {x, y + w}, color, 1);
    }

}


void drawRadar(float dis, float RotationAngleX,float RotationAngleY, bool isAI, bool isDie, float MapX, float MapY, float RadarLocationX,float RadarLocationY, float angle,bool isde) 
{
    ImColor LC;
    if (isDie) {
        LC = ImColor(0, 0, 0, 200);//倒地颜色
    }  else if(isAI) {
        LC = ImColor(255,255,255,200);//人机颜色
    }  else {
        LC = ImColor(255, 0, 0, 200);//真人颜色   
    }
    if (dis > 0 && dis < 450) {

        float Offset_Maps[2] = {0, 0};

        Offset_Maps[0] = MapX;
        Offset_Maps[1] = MapY;

      
        float proportion = val[4] / 100.0;
        float MapSize = round(265 * proportion) / 2;

        float RadarLocation_X = RadarLocationX / (60.0f / proportion);
        float RadarLocation_Y = RadarLocationY / (60.0f / proportion);

        float my_height = MapSize;
        float my_width = MapSize;
        float off = MapSize / 2;

        if(isde)
            ImGui::GetForegroundDrawList()->AddRect({Offset_Maps[0] - off ,Offset_Maps[1] - off}, {my_width + Offset_Maps[0] - off, my_height + Offset_Maps[1] - off},ImColor(255,255,255,200), 0, 0, 1);


        if (RadarLocation_X < (-MapSize / 2.0f + 45.0f / 2.0f) || RadarLocation_Y < (-MapSize / 2.0f + 45.0f / 2.0f) || RadarLocation_X > (MapSize / 2.0f - 45.0f / 2.0f) || RadarLocation_Y > (MapSize / 2.0f - 45.0f / 2.0f)) 
        {
            float x1 = fabs(RadarLocation_X);
            float y1 = fabs(RadarLocation_Y);
            float z1 = fmax(x1, y1) / ((MapSize / 2) - (45.0f / 2.0f));
            RadarLocation_X = RadarLocation_X / z1;
            RadarLocation_Y = RadarLocation_Y / z1;
        }
        DrawRadar(angle, Offset_Maps[0] + RadarLocation_X, Offset_Maps[1] + RadarLocation_Y,LC);
        ImGui::GetForegroundDrawList()->AddRectFilled({Offset_Maps[0] + RadarLocation_X - 7.5f ,Offset_Maps[1] + RadarLocation_Y - 7.5f }, { Offset_Maps[0] + RadarLocation_X + 7.5f, Offset_Maps[1] + RadarLocation_Y + 7.5f}, LC, 0, 0);
        string temp;
        if (dis > 9 && dis < 100) 
        {
            temp = " " + to_string((int)dis);
        } else if (dis < 10) {
            temp = "  " + to_string((int)dis);
        } else {
            temp = to_string((int)dis);
        }
        auto textSize = ImGui::CountTextSize(NULL, temp.c_str(), 30);
        ImGui::GetForegroundDrawList()->AddText(NULL,30,{Offset_Maps[0] + RadarLocation_X - 13 - (textSize.x / 2), Offset_Maps[1] + RadarLocation_Y - 10}, ImColor(255,255,255,200), temp.c_str());
            
    }
}

#include "draw.h"
#include "sumtool.h"
#include "variable.h"
#include "id.h"
#include "drawfunc.h"
#include "My_font/zh_Font.h"

#define BotColor ImColor(0,255,0,200)
#define PlayerColor ImColor(255,0,0,200)
#define AllColor ImColor(255,255,255,200)

using namespace std;
static uint32_t orientation = -1;
ANativeWindow *window; 
// 屏幕信息
android::ANativeWindowCreator::DisplayInfo displayInfo;
// 窗口信息
ImGuiWindow *g_window;
int native_window_screen_x, native_window_screen_y;
std::unique_ptr<AndroidImgui>  graphics;
ImFont* zh_font = NULL;

bool M_Android_LoadFont(float SizePixels) {
    ImGuiIO &io = ImGui::GetIO();
    
    ImFontConfig config;
    config.FontDataOwnedByAtlas = false;
    config.SizePixels = SizePixels;
    config.OversampleH = 1;
    ::zh_font = io.Fonts->AddFontFromMemoryTTF((void *)OPPOSans_H, OPPOSans_H_size, 0.0f, &config, io.Fonts->GetGlyphRangesChineseFull());    
    io.Fonts->AddFontDefault(&config);
    return zh_font != nullptr;
}

void init_My_drawdata() {
    //ImGui::My_Android_LoadSystemFont(25.0f); //(加载系统字体 无法释放)
    M_Android_LoadFont(27.5f); //加载字体(还有图标)
	ImGuiStyle &style = ImGui::GetStyle();
    //style.WindowMinSize = ImVec2(150, 0);  
    style.FrameRounding = 10.0f;
    style.WindowRounding = style.FrameRounding;
    style.ChildRounding = style.FrameRounding;
    style.FrameRounding = style.FrameRounding;
    style.PopupRounding = style.FrameRounding;
    style.ScrollbarRounding = style.FrameRounding;
    style.GrabRounding = style.FrameRounding;
    style.LogSliderDeadzone = style.FrameRounding;
    style.TabRounding = style.FrameRounding;
    style.Alpha=0.75f;
    ImGui::PushStyleVar(ImGuiCol_Button, 0.5f);
    ImGui::PushStyleVar(ImGuiCol_ButtonHovered, 0.5f);
    ImGui::PushStyleVar(ImGuiCol_ButtonActive, 0.5f);
    ImGui::PushStyleVar(ImGuiCol_FrameBg, 0.5f);
    ImGui::PushStyleVar(ImGuiCol_FrameBgActive, 0.5f);
    ImGui::PushStyleVar(ImGuiCol_FrameBgHovered, 0.5f);
    ImGui::PushStyleVar(ImGuiCol_Header, 0.5f);
    ImGui::PushStyleVar(ImGuiCol_HeaderActive, 0.5f);
    ImGui::PushStyleVar(ImGuiCol_HeaderHovered, 0.5f);
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.0f, 0.0f, 0.0f, 0.75f);
	style.WindowTitleAlign = ImVec2(0.5, 0.5);
	cfgLoad("cfg.config");
}

void screen_config() {
    ::displayInfo = android::ANativeWindowCreator::GetDisplayInfo();
}

void drawBegin() {
    screen_config();
    if (::orientation != displayInfo.orientation) {
        ::orientation = displayInfo.orientation;
        if (g_window != NULL) {
            g_window->Pos.x = 100;
            g_window->Pos.y = 125;        
        }        
    }
}

string exec(string command)
{
    char buffer[128];
    string result = "";
    FILE* pipe = popen(command.c_str(), "r");
    if (!pipe) {
        return "popen failed!";
    }
    while (!feof(pipe)) {
        if (fgets(buffer, 128, pipe) != nullptr)
            result += buffer;
    }
    pclose(pipe);
    return result;
}

ImVec4 CalculateBreathColor()
{
    float r = 0.5f + 0.5f * sin(timernow + 0.5f);
    float g = 0.5f + 0.5f * sin(timernow + 1.0f);
    float b = 0.5f + 0.5f * sin(timernow + 1.5f);
    return ImVec4(r, g, b, 0.75f);
}

pid_t get_name_pid(char* PackageName) {
    pid_t pid=0;
    char cmd[0x100] = "pidof ";
    strcat(cmd, PackageName);
    FILE* fp = popen(cmd,"r");
    fscanf(fp,"%d", &pid);
    pclose(fp);
    return pid;
}

bool ButtonTextColored(const ImVec4& col, const char* fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    ImGui::TextColoredV(col, fmt, args);
    va_end(args);
    return ImGui::IsItemClicked();
}

void cfgSave(const char *name)
{
    if (numSave == nullptr) {
        string SaveFile = "/data/SANTFILE/";
        SaveFile += name;
        numSave = fopen(SaveFile.c_str(), "wb+");
    }
    fseek(numSave, 0, SEEK_SET);
    fwrite(val, sizeof(int) * 50, 1, numSave);
    fwrite(swh, sizeof(bool) * 50, 1, numSave);
    fflush(numSave);
    fsync(fileno(numSave));
}

void cfgLoad(const char *name)
{
    if (numSave == nullptr) {
        string SaveFile = "/data/SANTFILE/";
        SaveFile += name;
        numSave = fopen(SaveFile.c_str(), "rb+");
    }
    if (numSave != nullptr) {
        fseek(numSave, 0, SEEK_SET);
        fread(val, sizeof(int) * 50, 1, numSave);
        fread(swh, sizeof(bool) * 50, 1, numSave);
    }
}

void draw(ImDrawList *Draw)
{
    string hello="和平单透版\n@NekoFre";
//    string hello="和平单透版\n@NekoFre\n检测信息:"+imeienc;
	Draw->AddText(NULL,40,{px/4,py+(py/3)*2}, ImColor(255,0,0,200), hello.c_str());
	
    if(!isyz||!isyz2) return;
    ImVec2 textSize;
    string stemp;
    driver.read(matrixaddr, matrix, 16 * 4);
    uintptr_t Oneself=driver.read<uintptr_t>(driver.read<uintptr_t>(driver.read<uintptr_t>(driver.read<uintptr_t>(driver.read<uintptr_t>(libue4addr+0x1073E0B8) + 0x98) + 0x88) + 0x30) + 0x30B0);
    //自身
    uintptr_t Ulevel = driver.read<uintptr_t>(Oneself + 0x90);
    uintptr_t Arrayaddr =driver.read<uintptr_t>(Ulevel + 0xA0);
    int Count = driver.read<int>(Ulevel + 0x8); 
    int myTeam = driver.read<int>(Oneself + 0xA98);
    //队伍编号
    Vector3A Z;
    driver.read(driver.read<uintptr_t>(Oneself + 0x278) + 0x1F0, &Z, sizeof(Z));
    //坐标
    int playercnt=0;
    if(swh[12]||swh[13]||swh[14]||swh[15]) wzkg=1;
    else wzkg=0;
    for(int i=0;i< Count;i++)
    {
        uintptr_t objectaddr = driver.read<uintptr_t>(Arrayaddr + 8*i);
        Vector3A D;
        if(driver.read<float>(objectaddr + 0x31E8) == 479.5)
        {
            driver.read(driver.read<uintptr_t>(objectaddr + 0x278) + 0x1F0, &D, sizeof(D));
            int Team = driver.read<int>(objectaddr + 0xA98);
            int isBot = driver.read<int>(objectaddr + 0xAB4);
            float Distance = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2) + pow(D.Z - Z.Z, 2)) * 0.01;
            float Health = (driver.read<float>(objectaddr + 0xe38) / driver.read<float>(objectaddr + 0xe40)) *100;
            if (Team == myTeam) {
                continue;
            }
            if(Team<-1||Team>=1001) continue;
            if (Distance > 600)
            {
                continue;
            }
            if(swh[9]&&isBot) continue;
            playercnt++;
            float camera = matrix[3] * D.X + matrix[7] * D.Y + matrix[11] * D.Z + matrix[15];
            float r_x = px + (matrix[0] * D.X + matrix[4] * D.Y + matrix[8] * D.Z + matrix[12]) / camera * px;
            float  r_y = py - (matrix[1] * D.X + matrix[5] * D.Y + matrix[9] * (D.Z - 5) + matrix[13]) / camera * py;
            float r_w = py - (matrix[1] * D.X + matrix[5] * D.Y + matrix[9] * (D.Z + 205) + matrix[13]) / camera * py;
            float X = r_x;
            float Y = r_y;
            float W = (r_y - r_w) / 2;
            float MIDDLE = X + W / 2;
            float BOTTOM = Y;
            if(!isyz||!isyz2) continue;
            Vector2A leida=WorldToScreen(D, matrix, camera);
            float bmyj = driver.read<float>(objectaddr + 0x198);
            float Angle = bmyj+90;
            if (Angle < 0)
               Angle += 360;
            Vector2A RadarLocation = Vector2A(D.X - Z.X, D.Y - Z.Y);
            Vector2A RotationAngle = rotateCoord(bmyj - 90.0f,(Z.X - D.X) / 225, (Z.Y - D.Y) / 225);
            if(swh[10])
            {
                drawRadar(Distance, RotationAngle.X, RotationAngle.Y, isBot, Health==0, val[2], val[3], RadarLocation.X, RadarLocation.Y, Angle,swh[16]);
            }
            if(swh[7])
            {
                if(isBot==1)
                {
                    OffScreen(Draw, leida, camera, BotColor, 200);
			    } else {
			        OffScreen(Draw, leida, camera, PlayerColor, 200);
                }
            }
            if(W>0)
            {
                char playername[100]={};
                getUTF8(playername, driver.read<uintptr_t>(objectaddr + 0xA18));
                int scid=driver.read<int>(driver.read<uintptr_t>(objectaddr + 0xF48) + 0xB90);
                uintptr_t Mesh = driver.read<uintptr_t>(objectaddr + 0x5E8);
                uintptr_t human = Mesh + 0x1E0;
                uintptr_t Bone = driver.read<uintptr_t>(Mesh + 0x790) + 0x30;
                int BoneCount = driver.read<int>(Mesh + 0x790);
                int p = (BoneCount == 68) ? 33 : 32;
                int o = (BoneCount == 68) ? 34 : 33;
                int a = (BoneCount == 68) ? 13 : 63;
                int b = (BoneCount == 68) ? 35 : 62;
                int c = (BoneCount == 68) ? 55 : 52;
                int d = (BoneCount == 68) ? 59 : 56;
                int e = (BoneCount == 68) ? 56 : 53;
                int f = (BoneCount == 68) ? 60 : 57;
                int g = (BoneCount == 68) ? 57 : 54;
                int h = (BoneCount == 68) ? 61 : 58;
                // 计算骨节
                FTransform meshtrans = getBone(human);
                FMatrix c2wMatrix = TransformToMatrix(meshtrans);
                // 头部
                FTransform headtrans = getBone(Bone + 5 * 48);
                FMatrix boneMatrix = TransformToMatrix(headtrans);
                Vector3A relLocation = MarixToVector(MatrixMulti(boneMatrix, c2wMatrix));
                relLocation.Z += 7; // 脖子长度
                Vector2A Head = WorldToScreen(relLocation, matrix, camera);
                // 脖子
                FTransform chesttrans = getBone(Bone + 4 * 48);
                FMatrix boneMatrix1 = TransformToMatrix(chesttrans);
                Vector3A relLocation1 = MarixToVector(MatrixMulti(boneMatrix1, c2wMatrix));
                Vector2A Chest = WorldToScreen(relLocation1, matrix, camera);
                
                FTransform naizi = getBone(Bone + 3 * 48);
                FMatrix naizi1 = TransformToMatrix(naizi);
                Vector3A naizipos = MarixToVector(MatrixMulti(naizi1, c2wMatrix));
                Vector2A scrnaizi = WorldToScreen(naizipos, matrix, camera);
                // 肚子
                FTransform pelvistrans = getBone(Bone + 1 * 48);
                FMatrix boneMatrix2 = TransformToMatrix(pelvistrans);
                Vector3A LrelLocation1 = MarixToVector(MatrixMulti(boneMatrix2, c2wMatrix));
                Vector2A Pelvis = WorldToScreen(LrelLocation1, matrix, camera);
                // 左肩膀
                FTransform lshtrans = getBone(Bone + 11 * 48);
                FMatrix boneMatrix3 = TransformToMatrix(lshtrans);
                Vector3A relLocation2 = MarixToVector(MatrixMulti(boneMatrix3, c2wMatrix));
                Vector2A Left_Shoulder = WorldToScreen(relLocation2, matrix, camera);
                // 右肩膀
                FTransform rshtrans = getBone(Bone + p * 48);
                FMatrix boneMatrix4 = TransformToMatrix(rshtrans);
                Vector3A relLocation3 = MarixToVector(MatrixMulti(boneMatrix4, c2wMatrix));
                Vector2A Right_Shoulder = WorldToScreen(relLocation3, matrix, camera);
                // 左手肘
                FTransform lelbtrans = getBone(Bone + 12 * 48);
                FMatrix boneMatrix5 = TransformToMatrix(lelbtrans);
                Vector3A relLocation4 = MarixToVector(MatrixMulti(boneMatrix5, c2wMatrix));
                Vector2A Left_Elbow = WorldToScreen(relLocation4, matrix, camera);
                // 右手肘
                FTransform relbtrans = getBone(Bone + o * 48);
                FMatrix boneMatrix6 = TransformToMatrix(relbtrans);
                Vector3A relLocation5 = MarixToVector(MatrixMulti(boneMatrix6, c2wMatrix));
                Vector2A Right_Elbow = WorldToScreen(relLocation5, matrix, camera);
                // 左手腕
                FTransform lwtrans = getBone(Bone + a * 48);
                FMatrix boneMatrix7 = TransformToMatrix(lwtrans);
                Vector3A relLocation6 = MarixToVector(MatrixMulti(boneMatrix7, c2wMatrix));
                Vector2A Left_Wrist = WorldToScreen(relLocation6, matrix, camera);
                // 右手腕
                FTransform rwtrans = getBone(Bone + b * 48);
                FMatrix boneMatrix8 = TransformToMatrix(rwtrans);
                Vector3A relLocation7 = MarixToVector(MatrixMulti(boneMatrix8, c2wMatrix));
                Vector2A Right_Wrist = WorldToScreen(relLocation7, matrix, camera);
                // 左大腿
                FTransform Llshtrans = getBone(Bone + c * 48);
                FMatrix boneMatrix9 = TransformToMatrix(Llshtrans);
                Vector3A LrelLocation2 = MarixToVector(MatrixMulti(boneMatrix9, c2wMatrix));
                Vector2A Left_Thigh = WorldToScreen(LrelLocation2, matrix, camera);
                // 右大腿
                FTransform Lrshtrans = getBone(Bone + d * 48);
                FMatrix boneMatrix10 = TransformToMatrix(Lrshtrans);
                Vector3A LrelLocation3 = MarixToVector(MatrixMulti(boneMatrix10, c2wMatrix));
                Vector2A Right_Thigh = WorldToScreen(LrelLocation3, matrix, camera);
                // 左膝盖
                FTransform Llelbtrans = getBone(Bone + e * 48);
                FMatrix boneMatrix11 = TransformToMatrix(Llelbtrans);
                Vector3A LrelLocation4 = MarixToVector(MatrixMulti(boneMatrix11, c2wMatrix));
                Vector2A Left_Knee = WorldToScreen(LrelLocation4, matrix, camera);
                // 右膝盖
                FTransform Lrelbtrans = getBone(Bone + f * 48);
                FMatrix boneMatrix12 = TransformToMatrix(Lrelbtrans);
                Vector3A LrelLocation5 = MarixToVector(MatrixMulti(boneMatrix12, c2wMatrix));
                Vector2A Right_Knee = WorldToScreen(LrelLocation5, matrix, camera);
                // 左脚腕
                FTransform Llwtrans = getBone(Bone + g * 48);
                FMatrix boneMatrix13 = TransformToMatrix(Llwtrans);
                Vector3A LrelLocation6 = MarixToVector(MatrixMulti(boneMatrix13, c2wMatrix));
                Vector2A Left_Ankle = WorldToScreen(LrelLocation6, matrix, camera);
                // 右脚腕
                FTransform Lrwtrans = getBone(Bone + h * 48);
                FMatrix boneMatrix14 = TransformToMatrix(Lrwtrans);
                Vector3A LrelLocation7 = MarixToVector(MatrixMulti(boneMatrix14, c2wMatrix));
                Vector2A Right_Ankle = WorldToScreen(LrelLocation7, matrix, camera);
                float TOP = Pelvis.Y - (Pelvis.Y - Head.Y) - W / 5;    
                if(swh[3]&&Team!=-1)
                {
                    if(isBot)
                    {
                        Draw->AddCircle({Head.X , Head.Y}, W/10, BotColor, 0);
                        Draw->AddLine({Head.X, Head.Y}, {Chest.X, Chest.Y}, BotColor,{1.5});
                        Draw->AddLine({Chest.X, Chest.Y}, {Pelvis.X, Pelvis.Y},BotColor,{1.5});
                        Draw->AddLine({Chest.X, Chest.Y}, {Left_Shoulder.X,Left_Shoulder.Y},BotColor,{1.5});
                        Draw->AddLine({Chest.X, Chest.Y}, {Right_Shoulder.X,Right_Shoulder.Y}, BotColor,{1.5});
                        Draw->AddLine({Left_Shoulder.X, Left_Shoulder.Y}, {Left_Elbow.X,Left_Elbow.Y}, BotColor,{1.5});
                        Draw->AddLine({Right_Shoulder.X, Right_Shoulder.Y},{Right_Elbow.X, Right_Elbow.Y}, BotColor,{1.5});
                        Draw->AddLine({Left_Elbow.X, Left_Elbow.Y}, {Left_Wrist.X,Left_Wrist.Y}, BotColor,{1.5});
                        Draw->AddLine({Right_Elbow.X, Right_Elbow.Y}, {Right_Wrist.X,Right_Wrist.Y}, BotColor,{1.5});
                        Draw->AddLine({Pelvis.X, Pelvis.Y}, {Left_Thigh.X, Left_Thigh.Y},BotColor,{1.5});
                        Draw->AddLine({Pelvis.X, Pelvis.Y}, {Right_Thigh.X,Right_Thigh.Y}, BotColor,{1.5});
                        Draw->AddLine({Left_Thigh.X, Left_Thigh.Y}, {Left_Knee.X,Left_Knee.Y}, BotColor,{1.5});
                        Draw->AddLine({Right_Thigh.X, Right_Thigh.Y}, {Right_Knee.X,Right_Knee.Y}, BotColor,{1.5});
                        Draw->AddLine({Left_Knee.X, Left_Knee.Y}, {Left_Ankle.X,Left_Ankle.Y}, BotColor,{1.5});
                        Draw->AddLine({Right_Knee.X, Right_Knee.Y}, {Right_Ankle.X,Right_Ankle.Y}, BotColor,{1.5});
                    }else{
                        Draw->AddCircle({Head.X , Head.Y}, W/10, PlayerColor, 0);
                        Draw->AddLine({Head.X, Head.Y}, {Chest.X, Chest.Y}, PlayerColor,{1.5});
                        Draw->AddLine({Chest.X, Chest.Y}, {Pelvis.X, Pelvis.Y},PlayerColor,{1.5});
                        Draw->AddLine({Chest.X, Chest.Y}, {Left_Shoulder.X,Left_Shoulder.Y},PlayerColor,{1.5});
                        Draw->AddLine({Chest.X, Chest.Y}, {Right_Shoulder.X,Right_Shoulder.Y}, PlayerColor,{1.5});
                        Draw->AddLine({Left_Shoulder.X, Left_Shoulder.Y}, {Left_Elbow.X,Left_Elbow.Y}, PlayerColor,{1.5});
                        Draw->AddLine({Right_Shoulder.X, Right_Shoulder.Y},{Right_Elbow.X, Right_Elbow.Y}, PlayerColor,{1.5});
                        Draw->AddLine({Left_Elbow.X, Left_Elbow.Y}, {Left_Wrist.X,Left_Wrist.Y}, PlayerColor,{1.5});
                        Draw->AddLine({Right_Elbow.X, Right_Elbow.Y}, {Right_Wrist.X,Right_Wrist.Y}, PlayerColor,{1.5});
                        Draw->AddLine({Pelvis.X, Pelvis.Y}, {Left_Thigh.X, Left_Thigh.Y},PlayerColor,{1.5});
                        Draw->AddLine({Pelvis.X, Pelvis.Y}, {Right_Thigh.X,Right_Thigh.Y}, PlayerColor,{1.5});
                        Draw->AddLine({Left_Thigh.X, Left_Thigh.Y}, {Left_Knee.X,Left_Knee.Y}, PlayerColor,{1.5});
                        Draw->AddLine({Right_Thigh.X, Right_Thigh.Y}, {Right_Knee.X,Right_Knee.Y}, PlayerColor,{1.5});
                        Draw->AddLine({Left_Knee.X, Left_Knee.Y}, {Left_Ankle.X,Left_Ankle.Y}, PlayerColor,{1.5});
                        Draw->AddLine({Right_Knee.X, Right_Knee.Y}, {Right_Ankle.X,Right_Ankle.Y}, PlayerColor,{1.5});
                    }
                }
                if(swh[1])
                {
                    Draw->AddRect({X-W/2, Y-W*2}, {X + W/2, Y}, ImColor(255,255,255,200), 0, 0, 1.5f);
                }
                if(swh[2])
                {
                    Draw->AddLine({px , 150}, {Head.X, TOP-105}, AllColor, {2.0});  
                }
                if (swh[6])
                {               
                    if(Health>0)
                    {
                        Draw->AddCircleArc({Head.X, TOP - 60},30.0f, {0.0f, Health*3.6}, ImColor(0,255,0,127),  0, 5.0f);    
                    }
                }
                
                if (swh[8])
                {
                    stemp = GetHolGunItem(scid);
                    textSize = ImGui::CountTextSize(NULL, stemp.c_str(), 25);
                    Draw->AddText(NULL,25,{Head.X - (textSize.x / 2), BOTTOM + 10}, ImColor(255,255,255,200), stemp.c_str());              
                }
                
                if (swh[5])
                {
                    stemp = std::to_string((int) Distance);   
                    textSize = ImGui::CountTextSize(NULL, stemp.c_str(), 30);
                    Draw->AddText(NULL,30,{Head.X - (textSize.x / 2), TOP - 75}, ImColor(255,255,255,200), stemp.c_str());                         
                }
                    
                if (swh[4])
                {                    
                    stemp="";
                    if (isBot == 1)
                    {
                        stemp += "[";
                        stemp += std::to_string(Team);
                        stemp += "] ";
                        stemp += "Bot";             
                        textSize = ImGui::CountTextSize(NULL, stemp.c_str(), 25);
                        Draw->AddText(NULL,25,{Head.X - (textSize.x / 2), TOP - 20}, BotRightColor,stemp.c_str());     
                    }else if(isBot == 0){                                                              
                        stemp += "[";
                        stemp += std::to_string(Team);
                        stemp += "] ";
                        stemp += playername;
                        textSize = ImGui::CountTextSize(NULL, stemp.c_str(), 25);
                        Draw->AddText(NULL,25,{Head.X - (textSize.x / 2), TOP - 20}, RightColor,stemp.c_str());                      
                    }
                }           
            }
        }else if(wzkg){
            char ClassName[64];
	        driver.read((driver.read<uintptr_t>(driver.read<uintptr_t>(gnameaddr + ((driver.read<int>(objectaddr + 24)) / 0x4000) * 0x8) + ((driver.read<int>(objectaddr + 24)) % 0x4000) * 0x8)) + 0xC, ClassName, 63);
	        ClassName[63]='\0';
	        char wzname[32] = {};
            int type= getMaterialName(ClassName,wzname);
            if (!type)
            {
              continue;
            }
            Vector3A WZ;
            driver.read(driver.read<uintptr_t>(objectaddr + 0x278) + 0x1F0, &WZ, sizeof(WZ)); // 对象坐标
            float camera = matrix[3] * WZ.X + matrix[7] * WZ.Y + matrix[11] * WZ.Z + matrix[15];
            float r_x =
            px + (matrix[0] * WZ.X + matrix[4] * WZ.Y + matrix[8] * WZ.Z +
            matrix[12]) / camera * px;
            float r_y =
            py - (matrix[1] * WZ.X + matrix[5] * WZ.Y + matrix[9] * (WZ.Z - 5) +
            matrix[13]) / camera * py;
            float r_w =
            py - (matrix[1] * WZ.X + matrix[5] * WZ.Y + matrix[9] * (WZ.Z + 205) +
            matrix[13]) / camera * py;
            float Distance =
            sqrt(pow(WZ.X - Z.X, 2) + pow(WZ.Y - Z.Y, 2) + pow(WZ.Z - Z.Z, 2)) * 0.01;
            float X = r_x - (r_y - r_w) / 4;
            float Y = r_y;
            float W = (r_y - r_w) / 2;
            if(W<0)
            {
                continue;
            }
            std::string sb;
            sb += wzname;
            sb += " [";
            sb += std::to_string((int) Distance);
            sb += "米";
            sb += "]";  
            textSize = ImGui::CountTextSize(NULL, sb.c_str(), 25);
            Draw->AddText(NULL,25,{X - (textSize.x / 2), Y}, wzclor, sb.c_str());
        }
    }
    if(swh[11])
    {
        stemp="";
        if (playercnt == 0)
        {
            stemp += "安全";                   
            textSize = ImGui::CountTextSize(NULL, stemp.c_str(), 60);
            Draw->AddText(NULL,60,{px + 3 - (textSize.x / 2), 85}, ImColor(0, 255, 0,200), stemp.c_str());
        }else{
    	    stemp += std::to_string(playercnt); 
            textSize = ImGui::CountTextSize(NULL, stemp.c_str(), 60);
            Draw->AddText(NULL,60,{px + 3 - (textSize.x / 2), 85}, ImColor(255, 0, 0,200), stemp.c_str());                   
    	}
	}
}

bool menu() 
{
        py = displayInfo.height/2;  
        px = displayInfo.width/2;
		ImGuiIO& io = ImGui::GetIO();
		static bool IsBall = true;
    	static float ANIM_SPEED = 0.25f;
    	static float Velua = IsBall ? 0.0f : 1.0f;
        Velua = ImClamp(Velua + (io.DeltaTime / ANIM_SPEED) * (IsBall ? 1.0f : -1.0f), 0.0f, 1.0f);
        if ((800 * Velua) >= 100 && (800 * Velua) <= 800 && (500 * Velua) >= 100 && (500 * Velua) <= 500) {
            ImGui::SetWindowSize("测试", {800 * Velua, 500 * Velua});
        }
        if ((800 * Velua) <= 100 && !IsBall) {
            BallSwitch = true;
            MemuSwitch = false;
        }
        timernow += breathSpeed * 0.1f;
        timernow = fmod(timernow, 2 * 3.14159f);
        static ImVec2 Pos = ImGui::GetWindowPos();
        static bool first=0;
		if (BallSwitch)
    	{
    	if (ImGui::Begin("Ball", &BallSwitch,  ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar))
        {
            ImGui::SetWindowSize("Ball", {270.0f, 200.0f});
            if(!first)
            {
            ImGui::SetWindowPos("Ball", Pos, ImGuiCond_Always);
            first=1;
            }
			Pos = ImGui::GetWindowPos();
    		ImGui::GetForegroundDrawList()->AddText(NULL,50,{Pos.x,Pos.y}, ImColor(CalculateBreathColor()), "SANT");
    		if (ImGui::IsItemActive()) {
    		if (!IsDown) {
    		IsDown = true;
    		ImagePos = ImGui::GetWindowPos();
    	    }
    	} else if (IsDown) {
    		IsDown = false;
    		if(ImagePos.x == ImGui::GetWindowPos().x && ImagePos.y == ImGui::GetWindowPos().y) {
    		IsBall = true;
    		MemuSwitch = true;
    		BallSwitch = false;
    		ImGui::SetWindowPos("测试", Pos, ImGuiCond_Always);
    		}
    	}
    		g_window = ImGui::GetCurrentWindow();
    	    ImGui::End();
    	}
    }
        if(MemuSwitch)
        {
           if (ImGui::Begin("测试", &MemuSwitch, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar))
            {
			Pos = ImGui::GetWindowPos();
    		ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {25 , 25});
            if (ImGui::BeginChild("##左侧菜单标题", ImVec2(200, -1), false, ImGuiWindowFlags_NoScrollbar));
                {
                    //ImGui::GetForegroundDrawList()->AddText(NULL,105,{Pos.x,Pos.y + 30}, ImColor(CalculateBreathColor()), "SANT");
            ImGui::SetWindowFontScale(2.857142857142857142);
            ImGui::SetCursorPos(ImVec2(0, 30));
            if (ButtonTextColored(ImColor(CalculateBreathColor()),"SANT"))
            {
            IsBall = false;
            if(first)
            ImGui::SetWindowPos("Ball", Pos, ImGuiCond_Always);
            }
            ImGui::SetWindowFontScale(1.0);
            ImGui::SetCursorPos({0, 180});
            ImGui::Separator();
            ImGui::ItemSize(ImVec2(0, 2));
            if (ImGui::Button("辅助主页", ImVec2(200, 75)))
            {
            MenuTab=1;
            }
            if (ImGui::Button("游戏透视", ImVec2(200, 75)))
            {
            MenuTab=2;
            }
            if (ImGui::Button("触摸自瞄", ImVec2(200, 75)))
            {
            MenuTab=3;
            }
            ImGui::EndChild();
            ImGui::PopStyleVar(1);
            ImGui::SameLine();
            ImGui::SeparatorEx(ImGuiSeparatorFlags_Vertical);
          	ImGui::SameLine();
            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {25 , 25});
        	ImGui::SameLine();
            if (ImGui::BeginChild("##右菜单", ImVec2(-1, -1), false))
            {
                ImGui::SetCursorPos(ImVec2(75, 0));
                ImGui::Text("官方TG @NekoFre");
                //ImGui::Text("渲染模式 : %s, gui版本 : %s", graphics->RenderName, IMGUI_VERSION);        
                if (ImGui::BeginChild("左侧标题", ImVec2(0, 0), false))
                {
                if(MenuTab==1)
                {
                    if(!init)
                    {
                    if (ImGui::Button("加载辅助",{235,70}))   
                    {    
                    driver.initialize(get_name_pid((char*)"com.pubg.krmobile"));
                                        libue4addr = driver.get_module_base("libUE4.so");
                                        matrixaddr = driver.read<uintptr_t>(driver.read<uintptr_t>(libue4addr + 0xDE1DE50) + 0x20) + 0x270;
                                        gnameaddr = driver.read<uintptr_t>(libue4addr+0xD877440);
                                        Uworld = driver.read<uintptr_t>(libue4addr + 0xDE49DE8); // 读取游戏世界
                                        if(libue4addr>0xFFFFFFFF&&gnameaddr>0xFFFFFFFF&&matrixaddr>0xFFFFFFFF) init=1;
                }
                if (!init&&ImGui::Button("退出辅助",{235,70}))   
                {
                return 0;
                }else if(init&&ImGui::Button("退出辅助",{500,70})){
                exit(0);
                }
                if (ImGui::Button("保存设置",{-1,70}))
                {        
             	cfgSave("cfg.config");   	  		  	
                }
              	ImGui::SliderInt("FPS", &val[1], 60, 120);
              	ImGui::Text("加载耗时 %.3f ms/帧率 %.1f FPS", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
                }else if(MenuTab==2){
                ImGui::Checkbox("方框", &swh[1]);
                ImGui::SameLine();
                ImGui::Checkbox("射线", &swh[2]);
                ImGui::SameLine();
                ImGui::Checkbox("骨骼", &swh[3]);
                                
                                ImGui::Checkbox("名字", &swh[4]);
                                ImGui::SameLine();
                                ImGui::Checkbox("距离", &swh[5]);
                                ImGui::SameLine();
                                ImGui::Checkbox("血量", &swh[6]);
                                
                                ImGui::Checkbox("人数", &swh[11]);
                                ImGui::SameLine();
                                ImGui::Checkbox("背敌", &swh[7]);
                                ImGui::SameLine();
                                ImGui::Checkbox("手持", &swh[8]);
                                
                                ImGui::Checkbox("忽机", &swh[9]);
                                ImGui::SameLine();
                                ImGui::Checkbox("雷达", &swh[10]);
                                ImGui::SameLine();
                                ImGui::Checkbox("投掷", &swh[12]);
                                
                                ImGui::Checkbox("载具", &swh[13]);
                                ImGui::SameLine();
                                ImGui::Checkbox("盒子", &swh[14]);
                                ImGui::SameLine();
                                ImGui::Checkbox("空投", &swh[15]);
                				if(swh[10])
                				{
                    				ImGui::Checkbox("雷达调试方框(对准小地图后关闭)", &swh[16]);
                                    ImGui::SliderInt("雷达位置X", &val[2],0,displayInfo.width);
                                    ImGui::SliderInt("雷达位置Y", &val[3],0,displayInfo.height);
                                    ImGui::SliderInt("雷达大小", &val[4],80,300);
                                }
                            }else if(MenuTab==3){
                        ImGui::Text("已规划 暂不更新自瞄");    
                            
                            }
                            }
                        }
                    }
                }
                ImGui::End();
            }
	    }
    if(init) draw(ImGui::GetForegroundDrawList());
    return 1;
}
